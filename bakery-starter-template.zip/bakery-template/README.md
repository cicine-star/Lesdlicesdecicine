# 🧁 Template Boutique Artisanale

Plateforme e-commerce pour pâtissières et boulangères artisanales.

## Ce que vous obtenez
- Site de commande en ligne pour vos clients
- Espace admin complet (commandes, stocks, planning, clients, stats)
- Tableau de bord mobile-first
- Caisse enregistreuse
- Gestion des avis

## Installation en 5 étapes

### Étape 1 — Créer votre base de données
1. Allez sur [supabase.com](https://supabase.com) et créez un compte gratuit
2. Créez un nouveau projet
3. Dans SQL Editor, copiez-collez le contenu de `setup.sql` et cliquez Run
4. Notez votre URL et votre clé anon (Settings > API)

### Étape 2 — Créer votre compte admin
1. Dans Supabase > Authentication > Users > Add user
2. Entrez votre email et un mot de passe
3. Cliquez Create user

### Étape 3 — Configurer votre boutique
1. Ouvrez le fichier `config.js`
2. Remplacez toutes les valeurs entre guillemets par les vôtres
3. En particulier : supabase_url et supabase_key (copiés à l'étape 1)

### Étape 4 — Mettre en ligne
1. Créez un compte sur [github.com](https://github.com) (gratuit)
2. Cliquez "Use this template" > "Create a new repository"
3. Nommez votre dépôt (ex: ma-patisserie)
4. Dans Settings > Pages > Source : sélectionnez "main" branch
5. Votre site est en ligne sur : votrecompte.github.io/ma-patisserie

### Étape 5 — Ajouter vos produits
1. Connectez-vous à votre espace admin (votresite/admin.html)
2. Allez dans l'onglet Produits
3. Supprimez les produits exemples et ajoutez les vôtres

## Besoin d'aide ?
Contactez [mettre contact] pour un accompagnement personnalisé.
