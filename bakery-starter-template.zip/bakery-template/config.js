// ============================================================
//  CONFIGURATION — Modifiez uniquement ce fichier
// ============================================================
var SHOP = {
  name:            "Ma Pâtisserie",
  tagline:         "Pâtisseries artisanales faites avec amour",
  whatsapp:        "596XXXXXXXXX",
  address:         "Votre ville",
  email:           "contact@mapâtisserie.fr",
  supabase_url:    "COLLER_ICI_VOTRE_URL_SUPABASE",
  supabase_key:    "COLLER_ICI_VOTRE_CLE_SUPABASE_ANON",
  color_primary:   "#5C2E0E",
  color_secondary: "#C8833B",
  currency:        "€",
  delivery_zones:  "Votre zone de livraison",
  pickup_address:  "Votre adresse de retrait"
};
