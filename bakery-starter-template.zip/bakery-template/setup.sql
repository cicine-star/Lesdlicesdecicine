-- ============================================================
-- SETUP COMPLET — Coller dans Supabase SQL Editor > New Query
-- ============================================================

CREATE TABLE IF NOT EXISTS orders (
  id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at    timestamptz DEFAULT now(),
  client_name   text,
  client_phone  text,
  items         jsonb,
  total         numeric,
  status        text DEFAULT 'pending',
  delivery_type text,
  delivery_date date,
  note          text,
  address       text,
  admin_note    text,
  acompte       numeric
);

CREATE TABLE IF NOT EXISTS blocked_dates (
  id     uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  date   date UNIQUE,
  reason text
);

CREATE TABLE IF NOT EXISTS reviews (
  id         uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  author     text,
  rating     int,
  comment    text,
  approved   boolean DEFAULT false
);

CREATE TABLE IF NOT EXISTS stock_items (
  id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at    timestamptz DEFAULT now(),
  name          text NOT NULL,
  category      text DEFAULT 'matiere_premiere',
  quantity      numeric DEFAULT 0,
  unit          text DEFAULT 'g',
  min_quantity  numeric DEFAULT 0,
  cost_per_unit numeric DEFAULT 0
);

CREATE TABLE IF NOT EXISTS stock_movements (
  id         uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  item_id    uuid REFERENCES stock_items(id) ON DELETE CASCADE,
  type       text,
  quantity   numeric,
  note       text
);

CREATE TABLE IF NOT EXISTS clients (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at  timestamptz DEFAULT now(),
  name        text,
  phone       text UNIQUE,
  type        text DEFAULT 'particulier',
  postal_code text,
  birthday    date,
  updated_at  timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS products (
  id          uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at  timestamptz DEFAULT now(),
  name        text NOT NULL,
  description text DEFAULT '',
  price       numeric(10,2) DEFAULT 0,
  category    text DEFAULT 'Gâteaux',
  emoji       text DEFAULT '🧁',
  available   boolean DEFAULT true,
  sort_order  integer DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
  key   text PRIMARY KEY,
  value text DEFAULT ''
);

-- Produits exemples (à remplacer par les vôtres dans l'onglet Produits de l'admin)
INSERT INTO products (name, price, category, emoji, available, sort_order) VALUES
  ('Croissant', 1.50, 'Viennoiseries', '🥐', true, 1),
  ('Pain au chocolat', 1.20, 'Viennoiseries', '🍫', true, 2),
  ('Muffin', 2.00, 'Mignardises sucrées', '🧁', true, 3),
  ('Tarte aux fruits', 3.50, 'Tartes', '🥧', true, 4),
  ('Gâteau personnalisé', 45.00, 'Gâteaux', '🎂', true, 5)
ON CONFLICT DO NOTHING;

-- Paramètres par défaut
INSERT INTO settings (key, value) VALUES
  ('shop_name', 'Ma Pâtisserie'),
  ('shop_tagline', 'Pâtisseries artisanales faites avec amour'),
  ('shop_phone', ''),
  ('shop_address', ''),
  ('color_primary', '#5C2E0E'),
  ('color_secondary', '#C8833B'),
  ('notif_email', ''),
  ('emailjs_service', ''),
  ('emailjs_template', ''),
  ('emailjs_pubkey', '')
ON CONFLICT DO NOTHING;
